Resources used to do project and for what purpose:

(these are in addition to the links on the project site)

how to connect to database:
https://www.ionos.com/digitalguide/websites/web-development/use-php-to-retrieve-information-from-a-mysql-mariadb-database/

how to use html forms with php:
https://www.w3schools.com/php/php_form_complete.asp

w3schools php tutorial for syntax purposes mostly:
https://www.w3schools.com/php/default.asp

mysqli interface for php:
https://www.php.net/manual/en/book.mysqli.php

had php error due to misformatting of html:
https://stackoverflow.com/questions/47278348/php-output-echoed-out-of-order

html basics:
https://www.w3schools.com/html/html_basic.asp

creating navigation bar in html:
https://developer.mozilla.org/en-US/docs/Web/HTML/Element/nav

passing parameters back to form:
https://stackoverflow.com/questions/24453038/pass-parameter-to-form-action-in-html/24453212

had an html form problem where once the done button was pressed, the page wouldn't reload properly:
https://stackoverflow.com/questions/65880611/how-to-pass-a-hidden-parameter-back-to-the-form-action

inserting data using mysqli and php:
https://www.w3schools.com/php/php_mysql_insert.asp



