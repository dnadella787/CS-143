<!DOCTYPE html>
<html>
<body>

<H1 align="center"> Project 2 CS143 Home Page </H1>


<nav>
  <ul>
  <h3> Navigation </h3>
    <ul>
      <li><strong>Home</strong></li>
      <li><a href="search.php">Search Actor/Movie</a></li>
      <li><a href="actorinfo.php?actor=52794">Actor Information Page</a></li>
      <li><a href="movieinfo.php?movie=2632">Movie Information Page</a></li>
      <li><a href="reviews.php?review=2632">Add Movie Review</a></li>
    </ul>
  </ul>
</nav>



<ul>
    <h3> Student Info: </h3>
    <ul>
        <p>Dhanush Nadella 
        <br>UID: 205150583
        <br>Professor Cho <p>
    </ul>
</ul>

</body>
</html>




