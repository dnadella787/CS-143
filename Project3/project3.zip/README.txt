
for json formatting purposes (to place commas) I needed to find when I was on the 
last row of a query output:
https://stackoverflow.com/questions/12123933/php-check-mysql-last-row

python json parsing documentation and tutorials:
https://docs.python.org/3/library/json.html

https://www.w3schools.com/python/python_json.asp

