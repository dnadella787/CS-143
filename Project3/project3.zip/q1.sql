-- What is the id of marie curie?


SELECT id
FROM Laureates
WHERE givenName = "Marie" AND familyName = "Curie";
