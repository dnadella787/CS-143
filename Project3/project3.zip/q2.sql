
-- What country is the affiliation "CERN" located in?

SELECT DISTINCT affilCountry
FROM LaureatePrizes
WHERE affilName = "CERN";