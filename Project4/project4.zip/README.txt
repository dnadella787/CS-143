how to pretty print json using json_encode in php:
https://stackoverflow.com/questions/6054033/pretty-printing-json-with-php

how to print json object using result from executeQuery:
https://stackoverflow.com/questions/14232261/how-to-return-json-data-from-php-mongocursor

how to count distinct objects using $group twice:
https://stackoverflow.com/questions/24761266/select-group-by-count-and-distinct-count-in-same-mongodb-query

how to check if an attribute exists in a document for aggregate pipeline:
https://stackoverflow.com/questions/25497150/mongodb-aggregate-by-field-exists

Part E (Reflection):

Although the portions where we had to load the data into the database and retrieve the json again
was very easy compared to last time, the actual queries were much much harder and syntactically
challenging. I much more like the SQL system since usage down the line is simple. I will never 
use a No SQL db for personal projects most likely because of this. Honestly, even though the loading
and retrieval part was harder in Project 3, I still think that it is not so time consuming that 
I would mind it. I think I would save more time issuing queries down the line so it'd be worth it.