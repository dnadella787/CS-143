using itertools and itertools.combinations:
https://docs.python.org/3/library/itertools.html#itertools.combinations


possible ways to get all combinations within a list:
https://stackoverflow.com/questions/464864/how-to-get-all-possible-combinations-of-a-list-s-elements


filter:
https://sparkbyexamples.com/pyspark/pyspark-where-filter/